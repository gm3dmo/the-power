export default [ "Top", "Right", "Bottom", "Left" ];
