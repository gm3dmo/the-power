jQuery( function() {
	startIframeTest( getComputedSupport( jQuery.support ) );
} );
